# Zip Example Mod

Đây là mod mẫu dạng `.zip` chỉ chứa data‑mod.

## Dùng nhanh

1. Nén toàn bộ nội dung thư mục này thành `zip-example.zip`.
2. Thả file zip vào thư mục `mods/` của game.
3. Vào **Settings > Data > Mods** để bật/tắt mod.

## Nội dung

- `mod.json`: thông tin mod.
- `items.json`: 1 item mẫu (Glow Berry).
